-- Silkroad Hub starter schema (Supabase/Postgres)
-- Review and test policies before using this for real users.
create extension if not exists pgcrypto;

create type public.member_role as enum ('player','server_owner','admin');
create type public.owner_status as enum ('pending','verified','rejected','suspended');
create type public.content_status as enum ('pending','approved','rejected','removed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 32),
  role public.member_role not null default 'player',
  created_at timestamptz not null default now()
);

create table public.owner_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  server_name text not null check (char_length(server_name) between 2 and 100),
  website_url text,
  discord_url text,
  proof_text text not null,
  status public.owner_status not null default 'pending',
  admin_note text,
  created_at timestamptz not null default now()
);

create table public.servers (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id),
  name text not null check (char_length(name) between 2 and 100),
  cap text not null,
  race text not null check (race in ('Avrupa','Çin','EU + CH')),
  description text not null default '',
  website_url text,
  discord_url text,
  opening_at timestamptz,
  status text not null default 'upcoming' check (status in ('upcoming','online','closed')),
  owner_verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.posters (
  id uuid primary key default gen_random_uuid(),
  server_id uuid not null references public.servers(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id),
  title text not null check (char_length(title) between 3 and 140),
  image_path text not null,
  description text not null default '',
  status public.content_status not null default 'pending',
  admin_note text,
  approved_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.likes (
  user_id uuid not null references auth.users(id) on delete cascade,
  poster_id uuid not null references public.posters(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, poster_id)
);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  poster_id uuid not null references public.posters(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid references auth.users(id) on delete set null,
  poster_id uuid references public.posters(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create index posters_status_created_idx on public.posters(status, created_at desc);
create index servers_status_created_idx on public.servers(status, created_at desc);
create index owner_apps_user_status_idx on public.owner_applications(user_id, status);

-- All public-facing tables use RLS. Grants are intentionally conservative.
alter table public.profiles enable row level security;
alter table public.owner_applications enable row level security;
alter table public.servers enable row level security;
alter table public.posters enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.reports enable row level security;

revoke all on public.profiles, public.owner_applications, public.servers, public.posters, public.likes, public.comments, public.reports from anon, authenticated;
grant select on public.servers, public.posters to anon, authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.owner_applications to authenticated;
grant insert, update on public.servers to authenticated;
grant select, insert, update on public.posters to authenticated;
grant select, insert, delete on public.likes to authenticated;
grant select, insert on public.comments to authenticated;
grant insert, select on public.reports to authenticated;

-- Public sees only active servers and approved posters.
create policy "Public reads active servers" on public.servers for select to anon, authenticated using (status <> 'closed');
create policy "Owners read own applications" on public.owner_applications for select to authenticated using (user_id = (select auth.uid()));
create policy "Users submit own application" on public.owner_applications for insert to authenticated with check (user_id = (select auth.uid()));
create policy "Users read own profile" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy "Users update own profile" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- Approved posters are public. Pending/rejected items are visible to their owner only.
create policy "Read approved posters or own submissions" on public.posters for select to anon, authenticated using (status = 'approved' or owner_user_id = (select auth.uid()));
create policy "Owner creates pending posters" on public.posters for insert to authenticated with check (
 owner_user_id = (select auth.uid()) and status = 'pending'
 and exists (select 1 from public.servers s where s.id = server_id and s.owner_user_id = (select auth.uid()) and s.owner_verified = true)
);
create policy "Owner edits own pending posters" on public.posters for update to authenticated using (owner_user_id = (select auth.uid()) and status = 'pending') with check (owner_user_id = (select auth.uid()) and status = 'pending');

create policy "Users read own likes" on public.likes for select to authenticated using (user_id = (select auth.uid()));
create policy "Users add own likes" on public.likes for insert to authenticated with check (user_id = (select auth.uid()));
create policy "Users remove own likes" on public.likes for delete to authenticated using (user_id = (select auth.uid()));
create policy "Read comments on approved posters" on public.comments for select to anon, authenticated using (exists (select 1 from public.posters p where p.id = poster_id and p.status = 'approved'));
create policy "Authenticated users comment" on public.comments for insert to authenticated with check (user_id = (select auth.uid()) and exists (select 1 from public.posters p where p.id = poster_id and p.status = 'approved'));
create policy "Authenticated users report" on public.reports for insert to authenticated with check (reporter_user_id = (select auth.uid()));
create policy "Users read own reports" on public.reports for select to authenticated using (reporter_user_id = (select auth.uid()));

-- IMPORTANT:
-- Do not allow users to assign themselves role='admin' or set owner_verified=true.
-- Implement admin moderation and owner verification with a trusted backend/Edge Function
-- using server-side secrets. Never put Supabase service_role/secret keys in the app.
-- The admin policies/functions and Storage bucket policies must be added and tested
-- before a public production launch.
