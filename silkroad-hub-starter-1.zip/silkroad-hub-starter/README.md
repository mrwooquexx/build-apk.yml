# Silkroad Hub — başlangıç projesi

Telefon öncelikli Silkroad PvP sunucu keşif/topluluk uygulaması için ilk prototip.

## Şu anda neler var?
- Mobil uyumlu karanlık/siyah-altın arayüz
- Örnek sunucu kartları, filtreler ve arama
- Beğeni butonu (bu prototipte yalnızca bu cihazda saklanır)
- Sunucu sahipliği başvuru formu
- Afiş gönderim formu ve görsel önizleme
- Demo admin kuyruğu: onaylama/reddetme
- PWA dosyaları
- Capacitor yapılandırması ve GitHub Actions üzerinden debug APK üretme akışı
- Supabase için başlangıç SQL şeması

## Önemli sınır
Bu paket henüz canlı üyelik/veritabanı ile bağlı değildir. Formlar ve admin kuyruğu tarayıcının `localStorage` alanında saklanır; farklı kullanıcılar arasında paylaşılmaz. Örnek sunucular demo verisidir. Admin ekranı güvenli bir yönetim paneli değildir ve gerçek moderasyon için kullanılmamalıdır.

## Telefonda APK üretme yolu
Bilgisayar gerekmeden yapılabilecek yol:
1. GitHub hesabı aç veya mevcut hesabına gir.
2. Bu ZIP'i açıp içindeki dosyaları bir GitHub deposuna yükle (GitHub mobil uygulaması veya tarayıcıdan dosya yükleme kullanılabilir).
3. Depoda `.github/workflows/build-apk.yml` dosyasının da bulunduğunu kontrol et.
4. GitHub deposunda **Actions** sekmesine gir. İlk kullanımda Actions'ı etkinleştirmen gerekebilir.
5. **Build Android APK** iş akışını seçip **Run workflow** çalıştır. `main` dalına dosyaları yüklemek de iş akışını tetikler.
6. İşlem tamamlanınca çalışmanın altındaki **Artifacts** bölümünden `silkroad-hub-debug-apk` dosyasını indir.
7. ZIP içindeki `app-debug.apk` dosyasını Android'e indirip kur. Android, tarayıcı/dosya yöneticisi için “bu kaynaktan uygulama yükleme” izni isteyebilir.

Bu, test amaçlı debug APK'dır. Google Play veya herkese dağıtım için imzalı release APK/AAB, gizlilik metni, uygulama ikonu ve testler ayrıca hazırlanmalıdır. GitHub Actions dosyası Android derlemesini dener; bağımlılık/SDK uyumsuzluğu olursa logdaki hataya göre düzeltilmelidir.

## Canlı backend kurulumu
1. Supabase'de yeni proje oluştur.
2. `supabase/schema.sql` dosyasını SQL Editor'de çalıştır.
3. Auth e-posta ayarlarını, doğrulama e-postasını ve yönlendirme adreslerini yapılandır.
4. Sunucu sahibi doğrulamasını ve admin moderasyonunu **Edge Function / güvenilir sunucu tarafında** tamamla.
5. Poster görselleri için private/public erişim kuralları belirlenmiş Storage bucket ve MIME/boyut kontrolleri ekle.
6. Frontend'i Supabase Auth ve veritabanına bağla. Sadece publishable key kullanılmalı; `service_role` veya secret key istemciye asla konmamalı.
7. RLS politikalarını test etmeden gerçek kullanıcı verisiyle yayına çıkma.

## Veritabanı varlıkları
- `profiles`: kullanıcı profili
- `owner_applications`: sunucu sahipliği doğrulama başvuruları
- `servers`: sunucu kayıtları
- `posters`: onay durumlu afişler
- `likes`: kullanıcı beğenileri
- `comments`: yorumlar
- `reports`: moderasyon şikâyetleri

## İlk sürüm için sonraki işler
- Supabase Auth kayıt/giriş ve profil
- Sahiplik doğrulamasını admin için güvenli bir Edge Function'a taşıma
- Storage upload ve görsel doğrulama
- Gerçek admin yetkisi ve denetim kaydı
- Arama/filtreleme, sayfalama, spam koruması
- Gizlilik politikası, kullanım şartları ve şikâyet/kaldırma süreci
- APK release imzalama ve uygulama ikonları

## Yerelde çalıştırma (bilgisayarı olan geliştirici için)
Node.js 22 ile:
```bash
npm install
npm run dev
```
Vite adresini aç. Android projesi üretmek için:
```bash
npm run build
npx cap add android
npx cap sync android
```
